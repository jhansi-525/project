# Github Trending Tracker

### Installation Instruction

```bash
conda create -n github_star_repo python=3.11 -y
conda activate github_star_repo
pip install -r requirements.txt
```